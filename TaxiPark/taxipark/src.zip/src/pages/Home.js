import React from 'react'
import Layout from './../components/Layout/Layout'
import banner2 from "../images/banner2.jpg"
import '../styles/HomeStyles.css'
import services1 from '../images/services1.png'
import services2 from '../images/services2.png'
import services3 from '../images/services3.png'
import services4 from '../images/services4.png'
import tariff1 from '../images/tariff1.png'
import tariff2 from '../images/tariff2.png'
import tariff3 from '../images/tariff3.png'
import tariff4 from '../images/tariff4.png'


const Home = () => {
  return (
    <Layout>
      <div className='home' style={{ backgroundImage: `url(${banner2})` }} >
        <div className="headerContainer">
          <div className='inp'>
            <h1>GET TAXI <span>ONLINE</span> </h1>
            <p>STANDART</p>
            <p>BUSINESS</p>
            <p>VIP</p>
            <p>BUS-MINIVAN</p>
            <input placeholder='From Address...' />
            <input placeholder='To...' />
            <input placeholder='Phone Number' />
            <input placeholder='Data and Time' />
            <button>GET TAXI</button>
          </div >
        </div>
      </div>



      {/* ------------------OUR SERVICES-------- */}
      <section id="services-container">
        <h3 className='h3'>WELCOME</h3>
        <h1 className="h-primary">Our Services</h1>

        <div className='single'>
          <div className="services">
            <div className="box">
              <img src={services1} alt='' />
              <h2 class="h-secondary">RAPID CITY TRANSFER</h2>
              <p className='para'>
                We will bring you quickly and comfortably to anywhere in your city
              </p>
            </div>
          </div>
          <div className="services">
            <div className="box">
              <img src={services2} alt='' />
              <h2 class="h-secondary">BOOKING A HOTEL</h2>
              <p className='para'>
                If you need a comfortable hotel, our operators will book it for you, and take a taxi to the address
              </p>
            </div>
          </div>
          <div className="services">
            <div className="box">
              <img src={services3} alt='' />
              <h2 class="h-secondary">AIRPORT TRANSFER</h2>
              <p className='para'>
                We will bring you quickly and comfortably to anywhere in your city
              </p>
            </div>
          </div>
          <div className="services">
            <div className="box">
              <img src={services4} alt='' />
              <h2 class="h-secondary">BAGGAGE TRANSPORT</h2>
              <p className='para'>
                If you need a comfortable hotel, our operators will book it for you, and take a taxi to the address
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* ----------------------TARIFFS----------------- */}
      <section id="tariffs-container">

        <h3 className='h3'>SEE OUR</h3>
        <h1 className="h-primary">TARIFFS</h1>

        <div className='single-tariffs'>
          <div className='tariffs'>
            <div className='box'>
              <img src={tariff1} alt='' />
              <h2 className='h-secondary'>STANDART</h2>
              <p className='para'>Standard sedan for a drive around the city at your service</p>
              <h1 className='price'>$2 /km</h1>
            </div>
          </div>
          <div className='tariffs'>
            <div className='box'>
              <img src={tariff2} alt='' />
              <h2 className='h-secondary'>BUSINESS</h2>
              <p className='para'>Standard sedan for a drive around the city at your service</p>
              <h1 className='price'>$2,7 /km</h1>

            </div>
          </div>
          <div className='tariffs'>
            <div className='box'>
              <img src={tariff3} alt='' />
              <h2 className='h-secondary'>VIP</h2>
              <p className='para'>Standard sedan for a drive around the city at your service</p>
              <h1 className='price'>$5 /km</h1>

            </div>
          </div>
          <div className='tariffs'>
            <div className='box'>
              <img src={tariff4} alt='' />
              <h2 className='h-secondary'>BUS-MINIVAN</h2>
              <p className='para'>Standard sedan for a drive around the city at your service</p>
              <h1 className='price'>$4.5 /km</h1>

            </div>
          </div>
        </div>
      </section >



    </Layout>
  )
}

export default Home
