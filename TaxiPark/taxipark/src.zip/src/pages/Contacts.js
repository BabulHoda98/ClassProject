import React from 'react'
import Layout from '../components/Layout/Layout'

const Contacts = () => {
    return (
        <Layout>
            Contacts
        </Layout>
    )
}

export default Contacts
