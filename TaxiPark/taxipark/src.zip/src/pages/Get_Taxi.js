import React from 'react'
import Layout from './../components/Layout/Layout'

const Get_Taxi = () => {
  return (
    <Layout>
      GetTexi
    </Layout>
  )
}

export default Get_Taxi

