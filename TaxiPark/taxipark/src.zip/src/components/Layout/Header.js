import React, { useState } from 'react'
import { AppBar, Box, Divider, Drawer, IconButton, Toolbar, Typography } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import { Link, NavLink } from 'react-router-dom';
import '../../styles/HeaderStyles.css'
import Logo from "../../images/logo.png"

const Header = () => {

    const [mobileOpen, setMobileOpen] = useState(false)
    // handle menu click
    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen)
    }
    //menu drawer
    const drawer = (
        <>
            <Box onClick={handleDrawerToggle} sx={{ textAlign: 'left' }}>
                <Typography
                    color={'Red'}
                    variant='h6'
                    component='div'
                    sx={{ flexGrow: 1, my: 2 }}>
                    Texy Park
                </Typography>
                <Divider />

                <ul className='mobile-navigation'>
                    <li>
                        <Link to={"/"}>Home</Link>
                    </li>
                    <li>
                        <Link to={"/get_taxi"}>Get_Taxi</Link>
                    </li>
                    <li>
                        <Link to={"/services"}>Services</Link>
                    </li>
                    <li>
                        <Link to={"/our_blog"}>Our_Blog</Link>
                    </li>
                    <li>
                        <Link to={"/gallery"}>Gallery</Link>
                    </li>
                    <li>
                        <Link to={"/shop"}>Shop</Link>
                    </li>
                    <li>
                        <Link to={"/contacts"}>Contacts</Link>
                    </li>
                    <li>
                        <Link to={"/pages"}>Pages</Link>
                    </li>
                </ul>
            </Box>
        </>
    );
    // -------------------------------------------------------------------------------------

    return (
        <>
            <Box>
                <AppBar component={'nav'} sx={{ bgcolor: 'black' }}>
                    {/* -----------------mobile view---------------------------- */}
                    <Toolbar>
                        <IconButton color='inherit' aria-label='open drawer' edge="start" sx={{ mr: 2, display: { sm: 'none' } }} onClick={handleDrawerToggle}>
                            <MenuIcon />
                        </IconButton>
                        <Typography color={'yellow'} variant='h6' component='div' sx={{ flexGrow: 1 }}>
                            {/* <DehazeIcon /> */}
                            Texy Park
                            {/* <img src={Logo} alt="logo" height={40} width={200}/> */}
                        </Typography>
                    </Toolbar>
                    <Box sx={{ display: { xs: "none", sm: "block" } }}>

                        <ul className='navigation-menu'>
                            <li>
                                <Link to={"/"}>Home</Link>
                            </li>
                            <li>
                                <Link to={"/get_taxi"}>Get_Taxi</Link>
                            </li>
                            <li>
                                <Link to={"/services"}>Services</Link>
                            </li>
                            <li>
                                <Link to={"/our_blog"}>Our_Blog</Link>
                            </li>
                            <li>
                                <Link to={"/gallery"}>Gallery</Link>
                            </li>
                            <li>
                                <Link to={"/shop"}>Shop</Link>
                            </li>
                            <li>
                                <Link to={"/contacts"}>Contacts</Link>
                            </li>
                            <div class="dropdown">
                                <button className="dropbtn">Dropdown
                                    <i className="fa fa-caret-down"></i>
                                </button>
                                <div className="dropdown-content">
                                    <a href="#">Link 1</a>
                                    <a href="#">Link 2</a>
                                    <a href="#">Link 3</a>
                                </div>
                            </div>
                        </ul>

                    </Box>

                    {/* ----------------------------------------- */}
                    <Box component="nav">
                        <Drawer variant='temporary' open={mobileOpen} onClose={handleDrawerToggle}
                            sx={{
                                display: { xs: 'block', sm: 'none' },
                                "& .MuiDrawer-paper": {
                                    boxSizing: "border-box",
                                    width: "240px"
                                }
                            }}
                        >
                            {drawer}
                        </Drawer>
                    </Box>

                    {/* ----------------------------------------- */}
                </AppBar>
            </Box>
            <Box>
                <Toolbar />
            </Box>
        </>
    )

}

export default Header
