import React from 'react'
import Layout from '../components/Layout/Layout'

const Services = () => {
    return (
        <Layout>
            Services
        </Layout>
    )
}

export default Services
