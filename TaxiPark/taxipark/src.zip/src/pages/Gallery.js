import React from 'react'
import Layout from '../components/Layout/Layout'

const Gallery = () => {
    return (
        <Layout>
            Gallery
        </Layout>
    )
}

export default Gallery
