import React from 'react'
import Layout from '../components/Layout/Layout'

const Pages = () => {
    return (
        <Layout>
            Pages
        </Layout>
    )
}

export default Pages
