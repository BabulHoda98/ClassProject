// import Tariff1 from '../images/tariff1.png'
// import Tariff2 from '../images/tariff2.png'
// import Tariff3 from '../images/tariff3.png'
// import Tariff4 from '../images/tariff4.png'

// export const TariffsList =[
//     {
//         name:'Tariff1',
//         description:'Lorem inpl shfal jfdhahfs',
//         image:Tariff1,
//         price:200,
//     },
//     {
//         name:'Tariff2',
//         description:'Lorem inpl shfal jfdhahfs',
//         image:Tariff2,
//         price:200,
//     },
//     {
//         name:'Tariff3',
//         description:'Lorem inpl shfal jfdhahfs',
//         image:Tariff3,
//         price:200,
//     },
//     {
//         name:'Tariff4',
//         description:'Lorem inpl shfal jfdhahfs',
//         image:Tariff4,
//         price:200,
//     },
// ]