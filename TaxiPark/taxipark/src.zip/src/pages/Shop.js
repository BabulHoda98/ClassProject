import React from 'react'
import Layout from '../components/Layout/Layout'

const Shop = () => {
    return (
        <Layout>
            Shop
        </Layout>
    )
}

export default Shop
